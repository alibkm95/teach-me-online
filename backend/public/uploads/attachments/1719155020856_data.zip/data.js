const data = [
  {
    title: "Python for Beginners",
    price: 29.99,
    description: "Learn the basics of Python programming",
    courseStatus: "recording",
    score: 4,
    cover: "python-cover.jpg",
    requirements: [],
    categories: [],
    lang: [],
    tags: []
  }, {
    title: "JavaScript Fundamentals",
    price: 19.99,
    description: "Master the basics of JavaScript",
    courseStatus: "completed",
    score: 5,
    cover: "js-cover.jpg",
    requirements: [],
    categories: [],
    lang: [],
    tags: []

  }, {
    title: "HTML/CSS Bootcamp",
    price: 39.99,
    description: "Learn HTML and CSS from scratch",
    courseStatus: "recording",
    score: 4,
    cover: "html-css-cover.jpg",
    requirements: [],
    categories: [],
    lang: [],
    tags: []

  }, {
    title: "React for Beginners",
    price: 49.99,
    description: "Build modern web applications with React",
    courseStatus: "completed",
    score: 5,
    cover: "react-cover.jpg",
    requirements: [],
    categories: [],
    lang: [],
    tags: []

  }, {
    title: "Node.js Essentials",
    price: 29.99,
    description: "Learn the basics of Node.js",
    courseStatus: "recording",
    score: 4,
    cover: "node-cover.jpg",
    requirements: [],
    categories: [],
    lang: [],
    tags: []

  }, {
    title: "Angular Crash Course",
    price: 59.99,
    description: "Learn Angular from scratch",
    courseStatus: "completed",
    score: 5,
    cover: "angular-cover.jpg",
    requirements: [],
    categories: [],
    lang: [],
    tags: []

  }, {
    title: "Vue.js Fundamentals",
    price: 39.99,
    description: "Master the basics of Vue.js",
    courseStatus: "recording",
    score: 4,
    cover: "vue-cover.jpg",
    requirements: [],
    categories: [],
    lang: [],
    tags: []

  }, {
    title: "Ruby on Rails Tutorial",
    price: 49.99,
    description: "Learn Ruby on Rails from scratch",
    courseStatus: "completed",
    score: 5,
    cover: "rails-cover.jpg",
    requirements: [],
    categories: [],
    lang: [],
    tags: []

  }, {
    title: "PHP for Beginners",
    price: 29.99,
    description: "Learn the basics of PHP",
    courseStatus: "recording",
    score: 4,
    cover: "php-cover.jpg",
    requirements: [],
    categories: [],
    lang: [],
    tags: []
  }, {
    title: "Java Programming Basics",
    price: 39.99,
    description: "Learn the basics of Java programming",
    courseStatus: "completed",
    score: 5,
    cover: "java-cover.jpg",
    requirements: [],
    categories: [],
    lang: [],
    tags: []
  }, {
    title: "C# Fundamentals",
    price: 49.99,
    description: "Master the basics of C#",
    courseStatus: "recording",
    score: 4,
    cover: "csharp-cover.jpg",
    requirements: [],
    categories: [],
    lang: [],
    tags: []
  }, {
    title: " Swift for iOS Development",
    price: 59.99,
    description: "Learn Swift for iOS development",
    courseStatus: "completed",
    score: 5,
    cover: "swift-cover.jpg",
    requirements: [],
    categories: [],
    lang: [],
    tags: []
  }, {
    title: "Kotlin for Android Development",
    price: 49.99,
    description: "Learn Kotlin for Android development",
    courseStatus: "recording",
    score: 4,
    cover: "kotlin-cover.jpg",
    requirements: [],
    categories: [],
    lang: [],
    tags: []
  }, {
    title: "Go Programming Language",
    price: 39.99,
    description: "Learn the basics of Go programming",
    courseStatus: "completed",
    score: 5,
    cover: "go-cover.jpg",
    requirements: [],
    categories: [],
    lang: [],
    tags: []
  }, {
    title: "Rust Programming Basics",
    price: 29.99,
    description: "Learn the basics of Rust programming",
    courseStatus: "recording",
    score: 4,
    cover: "rust-cover.jpg",
    requirements: [],
    categories: [],
    lang: [],
    tags: []
  }, {
    title: "TypeScript Fundamentals",
    price: 49.99,
    description: "Master the basics of TypeScript",
    courseStatus: "completed",
    score: 5,
    cover: "typescript-cover.jpg",
    requirements: [],
    categories: [],
    lang: [],
    tags: []
  }, {
    title: "SQL Database Management",
    price: 39.99,
    description: "Learn SQL database management",
    courseStatus: "recording",
    score: 4,
    cover: "sql-cover.jpg",
    requirements: [],
    categories: [],
    lang: [],
    tags: []
  }, {
    title: "NoSQL Database Fundamentals",
    price: 49.99,
    description: "Learn NoSQL database fundamentals",
    courseStatus: "completed",
    score: 5,
    cover: "nosql-cover.jpg",
    requirements: [],
    categories: [],
    lang: [],
    tags: []
  }, {
    title: "Machine Learning with Python",
    price: 59.99,
    description: "Learn machine learning with Python",
    courseStatus: "recording",
    score: 4,
    cover: "ml-cover.jpg",
    requirements: [],
    categories: [],
    lang: [],
    tags: []
  }, {
    title: "Deep Learning with TensorFlow",
    price: 69.99,
    description: "Learn deep learning with TensorFlow",
    courseStatus: "completed",
    score: 5,
    cover: "deep-learning-cover.jpg",
    requirements: [],
    categories: [],
    lang: [],
    tags: []
  }, {
    title: "Data Science with R",
    price: 49.99,
    description: "Learn data science with R",
    courseStatus: "recording",
    score: 4,
    cover: "r-cover.jpg",
    requirements: [],
    categories: [],
    lang: [],
    tags: []
  }, {
    title: "Data Visualization with D3.js",
    price: 39.99,
    description: "Learn data visualization with D3.js",
    courseStatus: "completed",
    score: 5,
    cover: "d3-cover.jpg",
    requirements: [],
    categories: [],
    lang: [],
    tags: []
  }, {
    title: "Cloud Computing with AWS",
    price: 59.99,
    description: "Learn cloud computing with AWS",
    courseStatus: "recording",
    score: 4,
    cover: "aws-cover.jpg",
    requirements: [],
    categories: [],
    lang: [],
    tags: []
  }, {
    title: "DevOps with Docker and Kubernetes",
    price: 69.99,
    description: "Learn DevOps with Docker and Kubernetes",
    courseStatus: "completed",
    score: 5,
    cover: "docker-kubernetes-cover.jpg",
    requirements: [],
    categories: [],
    lang: [],
    tags: []
  }, {
    title: "Cybersecurity Fundamentals",
    price: 49.99,
    description: "Learn cybersecurity fundamentals",
    courseStatus: "recording",
    score: 4,
    cover: "cybersecurity-cover.jpg",
    requirements: [],
    categories: [],
    lang: [],
    tags: []
  }
]